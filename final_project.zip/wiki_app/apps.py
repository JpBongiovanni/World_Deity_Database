from django.apps import AppConfig


class WikiAppConfig(AppConfig):
    name = 'wiki_app'
